__version__="0.1"

class Pepperanalytics:

    def  hola():
        """ function to return the string 'Hello World' """
        return("Hello World!!")
    

def adios():
    return ("Adios!")


